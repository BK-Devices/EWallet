package com.ewallet.rest;

import com.ewallet.beans.*;
import org.bson.*;
import java.util.*;
import com.mongodb.client.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/info")
public class RestBalance {
	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Wallet> allUsers(){
		ArrayList<Wallet> lst = new ArrayList<Wallet>();
		Wallet wall;
		
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
            iterDoc = coll.find();
            it = iterDoc.iterator();
            while(it.hasNext()){
            	doc = (Document) it.next();
            	if(!doc.getString("_id").equals("Admin")) {
                	wall = new Wallet();
            		wall.setName(doc.getString("Name"));
                	wall.setWallet_id(doc.getInteger("Wallet"));
                	wall.setBalance(doc.getDouble("Balance"));
                	wall.setType(doc.getString("Type"));
                	lst.add(wall);
            	}
            }
		}
		catch(Exception e) {
			System.out.println("AllUsers : " + e);
		}
		
		return lst;
	}
	
	@GET
	@Path("/single/{wallet}")
	@Produces(MediaType.APPLICATION_JSON)
	public Wallet singleUser(@PathParam("wallet") int id){
		Wallet wall = new Wallet();
		
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
            iterDoc = coll.find(new Document("Wallet", id));
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc = (Document) it.next();
            	wall.setName(doc.getString("Name"));
            	wall.setWallet_id(doc.getInteger("Wallet"));
            	wall.setBalance(doc.getDouble("Balance"));
            	wall.setType(doc.getString("Type"));
            }
            else{
            	wall.setName("Not Found");
            	wall.setWallet_id(id);
            	wall.setBalance(0.0);
            	wall.setType("Not Found");
            }
		}
		catch(Exception e) {
			System.out.println("SingleUsers : " + e);
		}
		
		return wall;
	}
	
	@POST
	@Path("/singlepost")
	@Produces(MediaType.APPLICATION_JSON)
	public Wallet singleUserPost(@FormParam("wallet_id") int id){
		Wallet wall = new Wallet();
		
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
            iterDoc = coll.find(new Document("Wallet", id));
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc = (Document) it.next();
            	wall.setName(doc.getString("Name"));
            	wall.setWallet_id(doc.getInteger("Wallet"));
            	wall.setBalance(doc.getDouble("Balance"));
            	wall.setType(doc.getString("Type"));
            }
            else{
            	wall.setName("Not Found");
            	wall.setWallet_id(id);
            	wall.setBalance(0.0);
            	wall.setType("Not Found");
            }
		}
		catch(Exception e) {
			System.out.println("SingleUsers : " + e);
		}
		
		return wall;
	}
}
