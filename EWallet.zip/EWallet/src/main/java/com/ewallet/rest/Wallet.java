package com.ewallet.rest;

public class Wallet {
	private String Name, Type;
	private int Wallet_id;
	private double Balance;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getWallet_id() {
		return Wallet_id;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public void setWallet_id(int wallet_id) {
		Wallet_id = wallet_id;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
}
