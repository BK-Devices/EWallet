package com.ewallet.beans;

import java.util.*;

public class Logs {
	private String date;
	private List<String> log;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<String> getLog() {
		return log;
	}
	public void setLog(List<String> log) {
		this.log = log;
	}
	
	
	
	
//	ObjectMapper mapper = new ObjectMapper();
//    mapper.enable(SerializationFeature.INDENT_OUTPUT);
//	
//	Logs obj;
//	
//	List<Logs> lst = new ArrayList<Logs>();
//	
//	for(int i = 0; i <= 5; i++){
//		obj = new Logs();
//		obj.setDate(String.valueOf(i));
//		List<String> log = new ArrayList<String>();
//		log.add("Los Angeles");
//		log.add("New York");
//		obj.setLog(log);
//		lst.add(obj);
//	}
//	System.out.println(lst);
//	
//	// Convert object to JSON string
//    String postJson = mapper.writeValueAsString(lst);
//    System.out.println(postJson);
}
