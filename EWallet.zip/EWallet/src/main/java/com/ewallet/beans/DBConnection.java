package com.ewallet.beans;

import com.mongodb.client.*;

public class DBConnection {
	private MongoClient client;
	private MongoDatabase db;
	
	public DBConnection(){
		try {
			client = MongoClients.create("mongodb+srv://BK-Devices:MongoDBPass@java.vgflxji.mongodb.net/?retryWrites=true&w=majority");
            db = client.getDatabase("EWallet");
		}
		catch(Exception e) {
			System.out.println("DBConnection : " + e);
		}
	}
	public MongoClient getClient() {
		return client;
	}
	public MongoDatabase getDb() {
		return db;
	}
}