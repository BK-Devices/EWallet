function createRequestObject() {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}
var http = createRequestObject();

var add_mess = document.getElementById("add-mess");
function addMoney(){
    event.preventDefault();
    add_mess.style.display = "block";
    add_mess.style.color = "#f00";
    bal = document.getElementById("add-amt").value;
    if (bal > 0){
        http.open("get", "MoneyOpr?typ=add&bal=" + bal);
        http.onreadystatechange = addMoneyResponse;
        http.send(null);
    }
    else {
        add_mess.innerHTML = "Please Enter Correct Data";
    }
}
function addMoneyResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            add_mess.innerHTML = "Money Not Added";
        }
        else if(response == "success"){
            add_mess.innerHTML = "Money Added Successfully";
            add_mess.style.color = "#009500";
        }
        else{
            add_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var trans_mess = document.getElementById("trans-mess");
function transferMoney(){
    event.preventDefault();
    trans_mess.style.display = "block";
    trans_mess.style.color = "#f00";
    bal = document.getElementById("trans-amt").value;
    id = document.getElementById("trans-id").value;
    if (bal > 0){
        http.open("get", "MoneyOpr?typ=friend&bal=" + bal + "&towid=" + id);
        http.onreadystatechange = transferMoneyResponse;
        http.send(null);
    }
    else {
        trans_mess.innerHTML = "Please Enter Correct Data";
    }
}
function transferMoneyResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            trans_mess.innerHTML = "Money Not Transfered";
        }
        else if(response == "success"){
            trans_mess.innerHTML = "Money Transfered Successfully";
            trans_mess.style.color = "#009500";
        }
        else if(response == "not found"){
            trans_mess.innerHTML = "Please Check Receiver Wallet Id";
        }
        else if(response == "low balance"){
            trans_mess.innerHTML = "You have Insufficient Balance";
        }
        else{
            trans_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var rech_mess = document.getElementById("rech-mess");
function recharge(){
    event.preventDefault();
    rech_mess.style.display = "block";
    rech_mess.style.color = "#f00";

    bal = document.getElementById("rech-amt").value;
    comp = document.getElementById("rech-comp").value;
    mono = document.getElementById("rech-mono").value;
    if (bal > 0 && mono.length == 10){
        http.open("get", "MoneyOpr?typ=rech&bal=" + bal + "&comp=" + comp + "&mono=91" + mono);
        http.onreadystatechange = rechargeResponse;
        http.send(null);
    }
    else {
        rech_mess.innerHTML = "Please Enter Correct Data";
    }
}
function rechargeResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            rech_mess.innerHTML = "Recharge Was unsuccessful";
        }
        else if(response == "success"){
            rech_mess.innerHTML = "Recharge Successfully";
            rech_mess.style.color = "#009500";
        }
        else if(response == "not found"){
            rech_mess.innerHTML = "Sorry Company Not Found";
        }
        else if(response == "low balance"){
            rech_mess.innerHTML = "You have Insufficient Balance";
        }
        else{
            rech_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var bill_mess = document.getElementById("bill-mess");
function bill(){
    event.preventDefault();
    bill_mess.style.display = "block";
    bill_mess.style.color = "#f00";

    bal = document.getElementById("bill-amt").value;
    comp = document.getElementById("bill-comp").value;
    if (bal > 0){
        http.open("get", "MoneyOpr?typ=bill&bal=" + bal + "&comp=" + comp);
        http.onreadystatechange = billResponse;
        http.send(null);
    }
    else {
        bill_mess.innerHTML = "Please Enter Correct Data";
    }
}
function billResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            bill_mess.innerHTML = "Bill Payment Was unsuccessful";
        }
        else if(response == "success"){
            bill_mess.innerHTML = "Bill Payment Successfully";
            bill_mess.style.color = "#009500";
        }
        else if(response == "not found"){
            bill_mess.innerHTML = "Sorry Company Not Found";
        }
        else if(response == "low balance"){
            bill_mess.innerHTML = "You have Insufficient Balance";
        }
        else{
            bill_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var log_date = document.getElementById("log-date");
var log_month = document.getElementById("log-month");
function changeLogInpType(val){
    if(val == "all"){
        log_date.style.display = "none";
        log_month.style.display = "none";
    }
    else if(val == "date"){
        log_date.style.display = "block";
        log_month.style.display = "none";
    }
    else{
        log_month.style.display = "block";
        log_date.style.display = "block";
    }
}

var log_mess = document.getElementById("log-mess");
function searchLog(){
    event.preventDefault();
    log_mess.style.display = "block";
    log_mess.style.color = "#f00";
    var typ = document.getElementById("log-typ").value;

    if(typ == "date"){
        date = log_date.value;
    }
    else if(typ == "month"){
        date = log_date.value;
    }
    else if(typ == "all"){
        date = "all";
    }
    if(date != ""){
        http.open("get", "SearchLog?typ=" + typ + "&date=" + date);
        http.onreadystatechange = searchLogResponse;
        http.send(null);
    }
    else {
        log_mess.innerHTML = "Please Enter Correct Data";
    }
}
var logs = document.getElementById("logs");
function searchLogResponse(){
    if(http.readyState == 4){
        log_mess.style.display = "block";
        logs.style.display = "none";
        log = JSON.parse(http.responseText).log;

        if(log == null){
            log_mess.innerHTML = "No Transactions available!";
        }
        else if(log == "error"){
            log_mess.innerHTML = "Sorry Connection error";
        }
        else{
            logstring = "";
            log_mess.style.display = "none";
            logs.style.display = "block";
            var keys = Object.keys(log);
            for (let i = 0; i < keys.length; i++){
                var key = keys[i];
                if(key != "_id"){
                    var month = log[key];
                    var inkeys = Object.keys(month);
                    for (let j = 0; j < inkeys.length; j++){
                        var inkey = inkeys[j];
                        logstring += "<p><b>" + inkey + " of " + key + "</b><br>";
                        var day = month[inkey];
                        var nos = Object.keys(day);
                        for (let k = 0; k < nos.length; k++){
                            var no = nos[k]
                            logstring += no + "] " + day[no] + "<br>";
                        }
                        logstring += "</p><br>";
                    }
                }
            }
            logs.innerHTML = logstring;
        }
    }
}

var new1 = document.getElementById("new-1");
var new1_mess = document.getElementById("new1-mess");
new1.addEventListener("input", () => {
    if(0 < new1.value.length){
        new1_mess.style.display = "block";

        if(4 > new1.value.length){
            new1_mess.innerHTML = "Weak";
            new1_mess.style.color = "#f00";
        }
        else if(4 <= new1.value.length && new1.value.length < 8){
            new1_mess.innerHTML = "Medium";
            new1_mess.style.color = "#cebd00";
        }
        else{
            new1_mess.innerHTML = "Strong";
            new1_mess.style.color = "#009500";
        }
    }
    else{
        new1_mess.style.display = "none";
    }
})
var new2 = document.getElementById("new-2");
var new2_mess = document.getElementById("new2-mess");
new2.addEventListener("input", () => {
    if(0 < new2.value.length){
        new2_mess.style.display = "block";

        if(new1.value != new2.value){
            new2_mess.innerHTML = "Password Doesn't Matched";
            new2_mess.style.color = "#f00";
        }
        else{
            new2_mess.innerHTML = "Password Matched";
            new2_mess.style.color = "#009500";
        }
    }
    else{
        new2_mess.style.display = "none";
    }
})

var pass_mess = document.getElementById("pass-mess");
function changePass(){
    event.preventDefault();
    old = document.getElementById("old").value;
    new1 = document.getElementById("new-1").value;
    new2 = document.getElementById("new-2").value;
    pass_mess.style.color = "#f00";
    pass_mess.style.display = "block";
    if(old.length > 0 && new1 == new2 && new1.length > 7){
        http.open("get", "ChangePass?psw=" + old + "&npsw=" + new1);
        http.onreadystatechange = changePassResponse;
        http.send(null);
    }
    else{
        pass_mess.innerHTML = "Please Enter Correct Data";
    }
}
function changePassResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            pass_mess.innerHTML = "Password Does Not Change";
        }
        else if(response == "success"){
            pass_mess.innerHTML = "Password Change Successfully";
            pass_mess.style.color = "#009500";
        }
        else if(response == "wrong pass"){
            pass_mess.innerHTML = "Your old Password is Wrong";
        }
    }
}

kyc_mess = document.getElementById("kyc-mess");
function updateKYC(){
    event.preventDefault();
    kyc_mess.style.color = "#f00";
    kyc_mess.style.display = "block";
    profimg = document.getElementById("new-1").files[0];
    kycimg = document.getElementById("new-2").files[0];
    if(((profimg.type && kycimg.type) == ("image/jpeg" || "image/png")) && ((profimg.size / 1024 && kycimg.size / 1024) <= 200)){
        http.open("get", "UpdateKYC?prof=" + old + "&kyc=" + new1);
        http.onreadystatechange = updateKYCResponse;
        http.send(null);
    }
    else{
        kyc_mess.innerHTML = "Please Enter Correct Data";
    }
}
function updateKYCResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            kyc_mess.innerHTML = "File uploading failed";
        }
        else if(response == "success"){
            kyc_mess.innerHTML = "File Upload successfully";
            kyc_mess.style.color = "#009500";
        }
        else{
            kyc_mess.innerHTML = "Sorry connection error";
        }
    }
}

function block(value){
    var home = document.getElementById("home").style;
    var money = document.getElementById("money").style;
    var log = document.getElementById("log").style;
    var pass = document.getElementById("pass").style;
    var kyc = document.getElementById("kyc").style;

    var home_li = document.getElementById("home-li");
    var money_li = document.getElementById("money-li");
    var log_li = document.getElementById("log-li");

    if(value == 'home'){
        home.display = "block";
        money.display = log.display = pass.display = kyc.display = "none";

        home_li.style = "background: #18173a; color: #fff;";
        money_li.style = log_li.style = "background: transparent; color: #18173a;";
    }
    else if(value == 'money'){
        home.display = log.display = pass.display = kyc.display = "none";
        money.display = "block";

        money_li.style = "background: #18173a; color: #fff;";
        home_li.style = log_li.style = "background: transparent; color: #18173a;";

        money('trans');
    }
    else if(value == 'log'){
        home.display = money.display = pass.display = kyc.display = "none";
        log.display = "block";
        
        log_li.style = "background: #18173a; color: #fff;";
        money_li.style = home_li.style = "background: transparent; color: #18173a;";

        document.getElementById("log-form").reset();
        logs.style.display = "none";
        log_mess.style.display = "none";
        log_date.style.display = "none";
        log_month.style.display = "none";
    }
    else if(value == 'pass'){
        home.display = money.display = log.display = kyc.display = "none";
        pass.display = "block";

        home_li.style = money_li.style = log_li.style = "background: transparent; color: #18173a;";

        document.getElementById("pass-form").reset();
        pass_mess.style.display = "none";
    }
    else if(value == 'kyc'){
        home.display = money.display = log.display = pass.display = "none";
        kyc.display = "block";

        home_li.style = money_li.style = log_li.style = "background: transparent; color: #18173a;";

        document.getElementById("kyc-form").reset();
    }
}

function money(value){
    var trans = document.getElementById("trans").style;
    var rech = document.getElementById("rech").style;
    var bill = document.getElementById("bill").style;
    var add = document.getElementById("add").style;

    var trans_li = document.getElementById("trans-li");
    var rech_li = document.getElementById("rech-li");
    var bill_li = document.getElementById("bill-li");
    var add_li = document.getElementById("add-li");

    if(value == 'trans'){
        trans.display = "block";
        rech.display = bill.display = add.display = "none";

        trans_li.style = "background: #18173a; color: #fff;";
        rech_li.style = bill_li.style = add_li.style = "background: transparent; color: #18173a;";

        document.getElementById("trans-form").reset();
    }
    else if(value == 'rech'){
        trans.display = bill.display = add.display = "none";
        rech.display = "block";

        rech_li.style = "background: #18173a; color: #fff;";
        trans_li.style = bill_li.style = add_li.style = "background: transparent; color: #18173a;";

        document.getElementById("reach-form").reset();
    }
    else if(value == 'bill'){
        trans.display = rech.display = add.display = "none";
        bill.display = "block";
        
        bill_li.style = "background: #18173a; color: #fff;";
        rech_li.style = trans_li.style= add_li.style = "background: transparent; color: #18173a;";

        document.getElementById("bill-form").reset();
    }
    else if(value == 'add'){
        trans.display = rech.display = bill.display = "none";
        add.display = "block";
        
        add_li.style = "background: #18173a; color: #fff;";
        rech_li.style = bill_li.style = trans_li.style = "background: transparent; color: #18173a;";

        document.getElementById("add-form").reset();
    }
}