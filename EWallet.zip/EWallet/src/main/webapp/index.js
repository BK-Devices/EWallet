function createRequestObject() {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}
var http = createRequestObject();

var up_id_mess = document.getElementById("up-id-mess");
function signUpId(){
    id = document.getElementById("up-id").value
    if (id.length > 4) {
        up_id_mess.style.display = "block";
        http.open("get", "CheckId?uid=" + id);
        http.onreadystatechange = signUpIdResponse;
        http.send(null);
    }
    else{
        up_id_mess.style.display = "none";
    }
}
function signUpIdResponse() {
    if(http.readyState == 4){
        response = http.responseText;
        up_id_mess.style.color = "#f00";
        if(response == "no"){
            up_id_mess.innerHTML = "Available";
            up_id_mess.style.color = "#009500";
        }
        else if(response == "yes"){
            up_id_mess.innerHTML = "Not available";
        }
        else{
            up_id_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var pass = document.getElementById("up-psw");
var psw_mess = document.getElementById("up-psw-mess");
pass.addEventListener("input", () => {
    if(0 < pass.value.length){
        psw_mess.style.display = "block";

        if(4 > pass.value.length){
            psw_mess.innerHTML = "Weak";
            psw_mess.style.color = "#f00";
        }
        else if(4 <= pass.value.length && pass.value.length < 8){
            psw_mess.innerHTML = "Medium";
            psw_mess.style.color = "#cebd00";
        }
        else{
            psw_mess.innerHTML = "Strong";
            psw_mess.style.color = "#009500";
        }
    }
    else{
        psw_mess.style.display = "none";
    }
})

var in_mess = document.getElementById("in-mess");
function signIn(){
    event.preventDefault();
    psw = document.getElementById("in-psw").value;
    http.open("get", "SignIn?uid=" + document.getElementById("in-id").value + "&psw=" + psw);
    http.onreadystatechange = signInResponse;
    http.send(null);
}
function signInResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        in_mess.style.display = "block";
        in_mess.style.color = "#f00";
        if(response == "Customer"){
            document.getElementById("signin").action = "user.jsp";
            document.getElementById("signin").submit();
        }
        else if(response == "Admin"){
            document.getElementById("signin").action = "admin.jsp";
            document.getElementById("signin").submit();
        }
        else if(response == "failed"){
            in_mess.innerHTML = "Please check your userid or password";
        }
        else if(response == "companylogin"){
            in_mess.innerHTML = "Sorry Company can't Signin. Please contact Admin";
        }
        else if(response == "Deactive"){
            in_mess.innerHTML = "Your Account was deactivated! Please contact Admin";
        }
        else{
            in_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var up_mess = document.getElementById("up-mess");
function signUp(){
    event.preventDefault();
    up_mess.style.display = "block";
    up_mess.style.color = "#f00";
    id = document.getElementById("up-id").value;
    nm = document.getElementById("up-nm").value;
    em = document.getElementById("up-em").value;
    if(id.length > 4 && nm.length > 4 && pass.value.length > 7 && em.length > 12){
        http.open("get", "SignUp?uid=" + id + "&nm=" + nm + "&typ=Customer&em=" + em + "&psw=" + pass.value);
        http.onreadystatechange = signUpResponse;
        http.send(null);
    }
    else{
        up_mess.innerHTML = "Please provide correct data";
    }
}
function signUpResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "success"){
            up_mess.style.color = "#009500";
            up_mess.innerHTML = "Congratulations You are registered successfully";
        }
        else if(response == "failed"){
            up_mess.innerHTML = "Please check your userid or password";
        }
        else{
            up_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var new1 = document.getElementById("new-1");
var new1_mess = document.getElementById("new1-mess");
new1.addEventListener("input", () => {
    if(0 < new1.value.length){
        new1_mess.style.display = "block";

        if(4 > new1.value.length){
            new1_mess.innerHTML = "Weak";
            new1_mess.style.color = "#f00";
        }
        else if(4 <= new1.value.length && new1.value.length < 8){
            new1_mess.innerHTML = "Medium";
            new1_mess.style.color = "#cebd00";
        }
        else{
            new1_mess.innerHTML = "Strong";
            new1_mess.style.color = "#009500";
        }
    }
    else{
        new1_mess.style.display = "none";
    }
})
var new2 = document.getElementById("new-2");
var new2_mess = document.getElementById("new2-mess");
new2.addEventListener("input", () => {
    if(0 < new2.value.length){
        new2_mess.style.display = "block";

        if(new1.value != new2.value){
            new2_mess.innerHTML = "Password Doesn't Matched";
            new2_mess.style.color = "#f00";
        }
        else{
            new2_mess.innerHTML = "Password Matched";
            new2_mess.style.color = "#009500";
        }
    }
    else{
        new2_mess.style.display = "none";
    }
})

var for_id = document.getElementById("for-id");
var otp_mess = document.getElementById("otp-mess");
function sendOTP(){
    otp_mess.style.color = "#f00";
    otp_mess.style.display = "block";
    if(for_id.value.length >= 2){
        http.open("get", "SendOTP?uid=" + for_id.value);
        http.onreadystatechange = sendOTPResponse;
        http.send(null);
    }
    else{
        otp_mess.innerHTML = "Please Enter Correct Data";
    }
}
function sendOTPResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        otp_mess.style.display = "block";
        otp_mess.style.color = "#f00";

        if(response == "failed"){
            otp_mess.innerHTML = "Password Does Recovered";
        }
        else if(response == "success"){
            otp_mess.style.color = "#009500";
            otp_mess.innerHTML = "OTP has been sent on your registered Email-id and Valid for 5 minutes";
            document.getElementById("for-btn").disabled = false;
        }
        else if(response == "wrong id"){
            otp_mess.innerHTML = "Wrong User Id";
        }
        else if(response == "try again"){
            otp_mess.innerHTML = "Something Wrong Please Try Again";
        }
        else{
            otp_mess.innerHTML = "Sorry connection error";
        }
    }
}

var for_mess = document.getElementById("for-mess");
function forgetPass(){
    event.preventDefault();
    for_mess.style.color = "#f00";
    for_mess.style.display = "block";
    otp = document.getElementById("otp").value;
    if(for_id.value.length >= 2 && otp.length == 6 && new1.value == new2.value && new1.value.length > 7){
        http.open("get", "ForgetPass?uid=" + for_id.value + "&otp=" + otp + "&psw=" + new1.value);
        http.onreadystatechange = forgetPassResponse;
        http.send(null);
    }
    else{
        for_mess.innerHTML = "Please Enter Correct User Id";
    }
}
function forgetPassResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        for_mess.style.display = "block";
        document.getElementById("for-btn").disabled = true;

        otp_mess.style.display = "none";
        new1_mess.style.display = "none";
        new2_mess.style.display = "none";
        document.getElementById("forget").reset();
        if(response == "failed"){
            for_mess.innerHTML = "Password Does Recovered";
        }
        else if(response == "success"){
            for_mess.innerHTML = "Password Recovered Successfully";
            for_mess.style.color = "#009500";
        }
        else if(response == "same pass"){
            for_mess.innerHTML = "You have given the same password";
            for_mess.style.color = "#009500";
        }
        else if(response == "wrong otp"){
            for_mess.innerHTML = "Wrong OTP";
        }
        else if(response == "try again"){
            for_mess.innerHTML = "Something Wrong Please Try Again";
        }
        else{
            for_mess.innerHTML = response;
        }
    }
}

function block(value){
    var home = document.getElementById("home").style;
    var rest = document.getElementById("rest").style;
    var sign = document.getElementById("sign").style;
    var regi = document.getElementById("regi").style;
    var pass = document.getElementById("pass").style;

    var home_li = document.getElementById("home-li");
    var rest_li = document.getElementById("rest-li");
    var sign_li = document.getElementById("sign-li");
    var regi_li = document.getElementById("regi-li");

    if(value == 'home'){
        home.display = "block";
        rest.display = sign.display = regi.display = pass.display = "none";
        
        home_li.style = "background: #18173a; color: #fff;";
        rest_li.style = sign_li.style = regi_li.style = "background: transparent; color: #18173a;";
    }
    else if(value == 'rest'){
        rest.display = "block";
        home.display = sign.display = regi.display = pass.display = "none";

        rest_li.style = "background: #18173a; color: #fff;";
        home_li.style = sign_li.style = regi_li.style = "background: transparent; color: #18173a;";
    }
    else if(value == 'sign'){
        sign.display = "block";
        home.display = rest.display = regi.display = pass.display = "none";

        sign_li.style = "background: #18173a; color: #fff;";
        home_li.style = rest_li.style = regi_li.style = "background: transparent; color: #18173a;";

        document.getElementById("signin").reset();
        in_id_mess.style.display = "none";
        in_mess.style.display = "block";
    }
    else if(value == 'regi'){
        regi.display = "block";
        home.display = rest.display = sign.display = pass.display = "none";

        regi_li.style = "background: #18173a; color: #fff;";
        home_li.style = rest_li.style = sign_li.style = "background: transparent; color: #18173a;";

        document.getElementById("signup").reset();
        up_id_mess.style.display = psw_mess.style.display = up_mess.style.display = "none";
    }
    else if(value == 'pass'){
        pass.display = "block";
        home.display = rest.display = sign.display = regi.display = "none";
        home_li.style = rest_li.style = sign_li.style = regi_li.style = "background: transparent; color: #18173a;";

        document.getElementById("forget").reset();
        for_mess.style.display = "none";
        otp_mess.style.display = "none";
        document.getElementById("for-btn").disabled = true;
    }
}