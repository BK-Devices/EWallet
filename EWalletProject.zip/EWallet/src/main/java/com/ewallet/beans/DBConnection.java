package com.ewallet.beans;

import com.mongodb.client.*;
import com.mongodb.client.MongoClient;

public class DBConnection {
	private MongoClient client;
	private MongoDatabase db;
	
	public DBConnection(){
		try {
			client = MongoClients.create("mongodb+srv://BK-Devices:MongoDBPass@ewallet.xhk2y.mongodb.net/?retryWrites=true&w=majority");
            db = client.getDatabase("EWallet");
		}
		catch(Exception e) {
			System.out.println("DBConnection : " + e);
		}
	}
	public MongoClient getClient() {
		return client;
	}
	public MongoDatabase getDb() {
		return db;
	}
}