package com.ewallet.beans;

import org.bson.*;

import java.util.*;
import com.mongodb.client.*;
import com.mongodb.client.result.*;

public class UserManager {
	private String uid;
	private String name;
	private String email;
	private String pass;
	private String typ;
	private String npsw;

	private ArrayList<Users> lst;
	
	private String checkid;
	private String signin;
	private String signup;
	private String change;
	private String forget;
	private String stat;
	
	
	
	public UserManager() {
		checkid = "no";
		signin = "failed";
		signup = "failed";
		change = "failed";
		forget = "failed";
		stat = "failed";
	}
	
	
	
	public String getUid() {
		return uid;
	}

	public String getTyp() {
		return typ;
	}

	public String getCheckid() {
		checkId();
		return checkid;
	}

	public String getSignin() {
		signIn();
		return signin;
	}

	public String getSignup() {
		signUp();
		return signup;
	}

	public String getChange() {
		changePass();
		return change;
	}

	public String getForget() {
		forgetPass();
		return forget;
	}
	
	public ArrayList<Users> getLst() {
		arrayListAllUsers();
		return lst;
	}

	public String getStat() {
		changeStat();
		return stat;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPsw(String pass) {
		this.pass = pass;
	}

	public void setTyp(String typ) {
		this.typ = typ;
	}

	public void setNpsw(String npsw) {
		this.npsw = npsw;
	}

	
	
	private void checkId() {
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
			doc = new Document("_id", uid);
            iterDoc = coll.find(doc);
            it = iterDoc.iterator();
            if(it.hasNext()) checkid = "yes";
            else checkid = "no";
		}
		catch (Exception e) {
			checkid = "error";
			System.out.println("checkId : " + e);
		}
	}
	
	
	
	private void signIn() {
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
			doc = new Document("_id", uid);
            iterDoc = coll.find(doc);
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc = (Document) it.next();
            	if(!doc.getString("Type").equals("Company")) {
	            	if(doc.getString("Password").equals(pass)) {
	            		if(doc.getString("Status").equals("Active")) {
	    					signin = "success";
	    					uid = doc.getString("_id");
	    					typ = doc.getString("Type");
	    				}
	    				else signin = "Deactive";
	            	}
	            	else signin = "failed";
            	}
            	else signin = "companylogin";
            }
            else signin = "failed";
		}
		catch (Exception e) {
			signin = "error";
			System.out.println("signIn : " + e);
		}
	}
	
	
	
	private void signUp() {
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	Random ran = new Random();
    	
    	String ch = "Y";
		int wid = 0;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
					
			doc = new Document("_id", uid);
            iterDoc = coll.find(doc);
            it = iterDoc.iterator();
            if(!it.hasNext()) {
            	while(ch.equals("Y"))
	            {
	                wid = ran.nextInt(100000, 200000);
	                iterDoc = coll.find(new Document("Wallet", wid));
	                it = iterDoc.iterator();
	                if(it.hasNext()) ch = "Y";
	                else ch = "N";
				}
            	if(typ.equals("Customer")) {
            		doc = new Document("_id", uid).append("Wallet", wid).append("Balance", 0.0).append("Name", name)
                			.append("Email", email).append("Type", typ).append("Status", "Active").append("Password", pass);
            	}
            	else {
            		doc = new Document("_id", uid).append("Wallet", wid).append("Balance", 0.0).append("Name", uid)
            				.append("Email", email).append("Type", typ).append("Status", "Active");
            	}
				coll.insertOne(doc);
				
            	WalletManager wallet = new WalletManager();
				wallet.newWallet(wid, "Wallet Created");
				
				SendMail Email = new SendMail();
				Email.mail(email, "New Registeration", "You are registered successfully");
				signup = "success";
            }
            else signup = "failed";
		}
		catch (Exception e) {
			signup = "error";
			System.out.println("signUp : " + e);
		}
	}
	
	
	
	private void forgetPass() {
		MongoDatabase db;
		Document doc1, doc2;
		UpdateResult res;
		Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
	        
        	doc1 = new Document("_id", uid);
	        doc2 = new Document("$set", new Document("Password", npsw));
	        res = coll.updateOne(doc1, doc2);
	        
	        if(res.getModifiedCount() >= 1) {
	        	iterDoc = coll.find(doc1);
	        	it = iterDoc.iterator();
	            doc2 = (Document) it.next();
	            
				SendMail Email = new SendMail();
				Email.mail(doc2.getString("Email"), "Forget Password", "Your password recovery successfully. \n If it is not you then contact Admin.");
				
				forget = "success";
	        }
	        else forget = "failed";
		}
		catch (Exception e) {
			forget = "error";
			System.out.println("forgetPass : " + e);
		}
	}
	
	
	
	private void changePass() {
		MongoDatabase db;
		Document doc1, doc2;
		UpdateResult res;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
				
			doc1 = new Document("_id", uid);
            iterDoc = coll.find(doc1);
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc2 = (Document) it.next();
            	if(doc2.getString("Password").equals(pass)) {
        	        res = coll.updateOne(doc1, new Document("$set", new Document("Password", npsw)));
        	        
        	        if(res.getModifiedCount() >= 1) {
        				SendMail Email = new SendMail();
        				Email.mail(doc2.getString("Email"), "Change Password", "Your password changed successfully. \n If it is not you then contact Admin.");
        				
        	        	change = "success";
        	        }
                    else change = "failed";
            	}
            	else change = "failed";
            }
            else change = "failed";
		}
		catch (Exception e) {
			change = "error";
			System.out.println("changePass : " + e);
		}
	}
	
	
	
	private void arrayListAllUsers() {
		lst = new ArrayList<Users>();
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
    	Users usr;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");

            iterDoc = coll.find();
            it = iterDoc.iterator();
            while(it.hasNext()) {
            	doc = (Document) it.next();
            	usr = new Users();
            	if(!doc.getString("_id").equals("Admin")) {
            		usr.setUid(doc.getString("_id"));
            		usr.setTyp(doc.getString("Type"));
            		usr.setStat(doc.getString("Status"));
            		usr.setWid(doc.getInteger("Wallet"));
            		lst.add(usr);
            	}
            }
		}
		catch (Exception e) {
			checkid = "error";
			System.out.println("ArrayList : " + e);
		}
	}
	
	
	
	private void changeStat() {
		MongoDatabase db;
		Document doc1, doc2;
		UpdateResult res;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			doc1 = new Document("_id", uid);
            iterDoc = coll.find(doc1);
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc2 = (Document) it.next();
            	if(doc2.getString("Status").equals("Active")) {
            		doc2 = new Document("$set", new Document("Status", "Deactive"));
        	        res = coll.updateOne(doc1, doc2);
        	        
        	        if(res.getModifiedCount() >= 1) stat = "success";
                    else stat = "failed";
            	}
            	else {
            		doc2 = new Document("$set", new Document("Status", "Active"));
        	        res = coll.updateOne(doc1, doc2);
        	        
        	        if(res.getModifiedCount() >= 1) stat = "success";
                    else stat = "failed";
            	}
            }
            else stat = "failed";
		}
		catch (Exception e) {
			stat = "error";
			System.out.println("changeStat : " + e);
		}
	}
}