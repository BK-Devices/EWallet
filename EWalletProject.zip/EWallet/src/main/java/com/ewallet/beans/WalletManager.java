package com.ewallet.beans;

import org.bson.*;
import java.util.*;
import java.text.*;
import java.util.Iterator;
import com.mongodb.client.*;
import com.mongodb.client.result.*;


public class WalletManager {
	private int wid;
	private int towid;
	private double bal;
	private String uid;
	private String comp;
	private String typ;
	private String mono;
	private String date;
	
	private String tbnm;
	private String colnm;
	
	private String trans;
	private String  add;
	private String logs;
	
	
	
	public WalletManager() {
		trans = "";
		add = "";
		tableColumn();
	}

	
	
	public void setTowid(int towid) {
		this.towid = towid;
	}
	
	public void setBal(double bal) {
		this.bal = bal;
	}
	
	public void setUid(String uid) {
		this.uid = uid;
	}
	
	public void setComp(String comp) {
		this.comp = comp;
	}
	
	public void setTyp(String typ) {
		this.typ = typ;
	}
	
	public void setMono(String mono) {
		this.mono = mono;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getLogs() {
		searchLog();
		return logs;
	}

	public String getTrans() {
		transfer();
		return trans;
	}
	
	public String getAdd() {
		addMoney();
		return add;
	}

	
	
	private void tableColumn() {
		Calendar cal = Calendar.getInstance();
		String month[] = new DateFormatSymbols().getShortMonths();
		
		tbnm = month[cal.get(Calendar.MONTH)] + String.valueOf(cal.get(Calendar.YEAR));
		int dt = cal.get(Calendar.DATE);
		
		if (dt == 1) colnm = String.valueOf(dt) + "st";
		else if (dt == 2) colnm = String.valueOf(dt) + "nd";
		else if (dt == 3) colnm = String.valueOf(dt) + "rd";
		else colnm = String.valueOf(dt) + "th";
	}
	
	
	
	public void newWallet(int id, String log) {
		MongoDatabase db;
		Document doc;
    	MongoCollection<Document> coll;
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Logs");
			doc = new Document("_id", id);
			coll.insertOne(doc);
			logManager(id, log);
			reportManager(1, "New");
		}
		catch (Exception e) {
			System.out.println("NewWallet : " + e);
		}
	}
	
	
	
	private void logManager(int id, String log) {
		MongoDatabase db;
		Document doc1, doc2;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
    	int no = 1;
    	
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Logs");
			doc1 = new Document("_id", id);
			iterDoc = coll.find(doc1);
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc2 = (Document) it.next();
            	doc2 = (Document) doc2.get(tbnm);
            	if(doc2 != null) {
            		doc2 = (Document) doc2.get(colnm);
					if(doc2 != null) no += doc2.size();
				}
            }
	        doc2 = new Document("$set", new Document((tbnm + "." + colnm + "." + no) , log));
	        coll.updateOne(doc1, doc2);
		}
		catch (Exception e) {
			System.out.println("logManager : " + e);
		}
	}
	
	
	
	public void reportManager(double amt, String ty) {
		MongoDatabase db;
		Document doc1, doc2;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
    	Calendar cal = Calendar.getInstance();
    	String dt = cal.get(Calendar.DATE) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);
    	
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Logs");
			doc1 = new Document("_id", "Report");
			iterDoc = coll.find(doc1);
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc2 = (Document) it.next();
            	if(!doc2.getString("Refresh").equals(dt)){
        			doc2 = new Document("$set", new Document("Add", 0.0).append("New", 0).append("Transfer", 0));
        			coll.updateOne(doc1, doc2);
            		coll.updateOne(doc1, new Document("$set", new Document("Refresh", dt)));
            	}
            	if(!ty.equals("Refresh")){
            		if(ty.equals("Add")) doc2 = new Document("$inc", new Document("Add", amt));
                	else if(ty.equals("New")) doc2 = new Document("$inc", new Document("New", 1));
                	else if(ty.equals("Trans")) doc2 = new Document("$inc", new Document("Transfer", 1));
                	coll.updateOne(doc1, doc2);
            	}
            }
		}
		catch (Exception e) {
			System.out.println("ReportManager : " + e);
		}
	}
	
	
	
	@SuppressWarnings("resource")
	private void transfer() {
		MongoDatabase db;
		Document doc1, doc2;
		UpdateResult res;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
		String from = "";
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			SendMail Email = new SendMail();
			
			doc1 = new Document("_id", uid);
            iterDoc = coll.find(doc1);
            it = iterDoc.iterator();
            if(it.hasNext()) {
            	doc2 = (Document) it.next();
            	wid = doc2.getInteger("Wallet");
            	from = doc2.getString("Email");
            	if(doc2.getDouble("Balance") - bal >= 0) {
    	            
            		if(typ.equals("friend")) {
            			doc2 = new Document("$inc", new Document("Balance", bal));
    	    	        res = coll.updateOne(new Document("Wallet", towid), doc2);
                		
    	    	        if(res.getModifiedCount() >= 1) {
    		    	        coll.updateOne(doc1, new Document("$inc", new Document("Balance", - bal)));
    		    	        
    			            logManager(wid, "Transfered " + String.valueOf(bal) + " Rs To " + String.valueOf(towid));
    	            		logManager(towid, "Received " + String.valueOf(bal) + " Rs From " + String.valueOf(wid));

    	    				Email.mail(from, "Money Transfer", "Money transfer successfully. \nYou have sent " + bal + " Rs to walled " + towid + ". \n If it is not you then contact Admin.");
    	            		
    	    				iterDoc = coll.find(new Document("Wallet", towid));
    	    	        	it = iterDoc.iterator();
    	    	            doc2 = (Document) it.next();
    	    	            
    	    				Email.mail(doc2.getString("Email"), "Money Transfer", "You have received " + bal + " Rs from walled " + wid + ".");
    	    				
    	            		trans = "success";
    	            		reportManager(1, "Trans");
    	    	        }
    	    	        else trans = "not found";
            		}
            		else {
            			doc2 = new Document("_id", comp);
    	    	        res = coll.updateOne(doc2, new Document("$inc", new Document("Balance", bal)));
                		
    	    	        if(res.getModifiedCount() >= 1) {
    		    	        coll.updateOne(doc1, new Document("$inc", new Document("Balance", - bal)));
    		    	        
    		                it = coll.find(doc2).iterator();
    		                doc2 = (Document) it.next();
    		                towid = doc2.getInteger("Wallet");
    		                
    		                if(typ.equals("bill")) {
    				            logManager(wid, "Bill Payment of" + String.valueOf(bal) + " Rs of " + comp);
    		            		logManager(towid, "Bill Payment of" + String.valueOf(bal) + " Rs From " + String.valueOf(wid));
    		            		if (bal >= 1000) {
    				    	        coll.updateOne(doc1, new Document("$inc", new Document("Balance", 50)));
    								logManager(wid, "Got 50 Rs Cashback on your transaction");
    							}
        	    	            
        	    				Email.mail(from, "Money Transfer", "Bill Payment successfully. \nYou have make payment of " + bal + " Rs to " + towid + " company. \n If it is not you then contact Admin.");
    		                }
    		                else {
    				            logManager(wid, mono + " Recharge of " + String.valueOf(bal) + " Rs of " + comp);
    		            		logManager(towid, "Recharge of " + String.valueOf(bal) + " Rs From " + String.valueOf(wid));
        	    	            
    		            		Email.mail(from, "Money Transfer", "Bill Payment successfully. \nYou have make payment of " + bal + " Rs to " + towid + " company. \n If it is not you then contact Admin.");
    		                }
    	            		
    	            		trans = "success";
    	            		reportManager(1, "Trans");
    	    	        }
    	    	        else trans = "not found";
            		}
            	}
            	else trans = "low balance";
            }
            else trans = "failed";
		}
		catch (Exception e) {
			trans = "error";
			System.out.println("Transfer : " + e);
		}
	}
	
	
	
	private void addMoney() {
		MongoDatabase db;
		Document doc1, doc2;
		UpdateResult res;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
    	int id = 0;
    	String from = "";
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
			doc1 = new Document("_id", uid);
            iterDoc = coll.find(doc1);
            it = iterDoc.iterator();
            if(it.hasNext()) {
            	doc2 = (Document) it.next();
            	id = doc2.getInteger("Wallet");
            	from = doc2.getString("Email");
            	
    	        res = coll.updateOne(doc1, new Document("$inc", new Document("Balance", bal)));
    	        if(res.getModifiedCount() >= 1) {
    	        	logManager(id, "Added Rs " + String.valueOf(bal));
    	        	reportManager(bal, "Add");
    	            
    				SendMail Email = new SendMail();
    				Email.mail(from, "Add Money", "Money is added successfully in your wallet. \nIf it is not you then contact Admin.");
    				
    	        	add = "success";
    	        }
                else add = "failed";
            }
            else add = "failed";
		}
		catch (Exception e) {
			add = "error";
			System.out.println("addMoney : " + e);
		}
	}
	
	
	
	public void searchLog() {
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	
    	String yrmo = "", dt = "";
        String month[] = new DateFormatSymbols().getShortMonths();
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
			iterDoc = coll.find(new Document("_id", uid));
            it = iterDoc.iterator();
            if(it.hasNext()) {
            	doc = (Document) it.next();
            	doc = new Document("_id", doc.getInteger("Wallet"));
            	coll = db.getCollection("Logs");
            	iterDoc = coll.find(doc);
                it = iterDoc.iterator();
                if(it.hasNext()) {
					doc = (Document) it.next();
                	
                	if(!typ.equals("all")) {
                		StringTokenizer st = new StringTokenizer(date, "-");
                        int i = 1;
                        String yr = "", mo = "";
                        while(st.hasMoreTokens()){
                            if (i == 1) yr = st.nextToken();
                            else if (i == 2) mo = st.nextToken();
                            else dt = st.nextToken();
                            i++;
                        }
                        
                		yrmo = month[Integer.parseInt(mo) - 1] + yr;
                		doc = (Document) doc.get(yrmo);
                		if(doc != null){
	                    	if(typ.equals("date")) {
	                    		if (Integer.parseInt(dt) == 1) dt = dt + "st";
	                    		else if (Integer.parseInt(dt) == 2) dt = dt + "nd";
	                    		else if (Integer.parseInt(dt) == 3) dt = dt + "rd";
	                    		else dt = dt + "th";
	                    		
	                    		doc = (Document) doc.get(dt);
	                    		if(doc != null){
	                    			doc = new Document(dt, doc);
	                    		}
	                    	}
	                    	if(doc != null){
	                    		doc = new Document(yrmo, doc);
	                    	}
                		}
                	}
                	logs = new Document("log", doc).toJson();
                }
            }
            else logs = new Document("log", null).toJson();
		}
		catch (Exception e) {
			logs = new Document("log", "error").toJson();
			System.out.println("searchLog : " + e);
		}
	}
}