package com.ewallet.beans;

public class SendMail {
	@SuppressWarnings("unused")
	public void mail(String to, String sub, String text) {
		String from = "prashantkale1000@gmail.com";
		String pass = "nrfrlhgedjgubsxb";
		String host = "smtp.gmail.com";
		String port = "465";
	}
}
