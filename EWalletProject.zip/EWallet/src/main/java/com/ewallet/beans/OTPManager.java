package com.ewallet.beans;

import java.util.*;
import org.bson.*;
import com.mongodb.client.*;

public class OTPManager {
	private String otpsent;
	private String uid;
	private String otp;
	
	public OTPManager() {
		otpsent = "failed";
		otp = "";
	}
	
	public String getOtpsent() {
		sendOTP();
		return otpsent;
	}
	public String getOtp() {
		return otp;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}
	
	private void sendOTP(){
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	Random ran = new Random();
    	SendMail Email = new SendMail();
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
			doc = new Document("_id", uid);
            iterDoc = coll.find(doc);
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc = (Document) it.next();
            	String email = doc.getString("Email");
            	otp = String.valueOf(ran.nextInt(100000, 999999));
//            	otp = "987654";
            	
            	Email.mail(email, "Forget Password", "Your OTP for password recovery is '" + otp + "'. \n If it is not you then contact Admin. \nAlso dont share this otp");
            	          	
            	otpsent = "success";
            }
            else otpsent = "wrong id";
		}
		catch (Exception e) {
			otpsent = "error";
			System.out.println("sendOTP : " + e);
		}
	}
}
