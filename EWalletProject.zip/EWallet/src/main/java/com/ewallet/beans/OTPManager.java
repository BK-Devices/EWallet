package com.ewallet.beans;

import java.io.*;
import java.util.*;
import org.bson.*;
import com.mongodb.client.*;

public class OTPManager {
	private String otpsent, uid, email;
	private int otp;
	
	public OTPManager() {
		otpsent = "failed";
	}
	
	public String getOtpsent() {
		sendOTP();
		return otpsent;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	
	private void sendOTP(){
		MongoDatabase db;
		Document doc;
    	Iterator<Document> it;
    	MongoCollection<Document> coll;
    	FindIterable<Document> iterDoc;
    	Random ran = new Random();
    	SendMail Email = new SendMail();
		
		try {
			DBConnection obj = new DBConnection();
			db = obj.getDb();
			coll = db.getCollection("Users");
			
            iterDoc = coll.find(new Document("_id", uid));
            it = iterDoc.iterator();
            if(it.hasNext()){
            	doc = (Document) it.next();
            	email = doc.getString("Email");
            	otp = ran.nextInt(100000, 200000);
            	otp = 987654;
            	
            	Email.mail(email, "Forget Password", "Your OTP for password recovery is '" + otp + "'. \n If it is not you then contact Admin. \nAlso dont share this otp");
            	
            	FileWriter fw = new FileWriter("otp.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(otp);
                bw.close();
            	
            	otpsent = "success";
            }
            else otpsent = "wrong id";
		}
		catch (Exception e) {
			otpsent = "error";
			System.out.println("sendOTP : " + e);
		}
	}
}
