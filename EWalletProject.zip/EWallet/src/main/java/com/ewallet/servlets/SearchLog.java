package com.ewallet.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ewallet.beans.WalletManager;

/**
 * Servlet implementation class SearchLog
 */
@WebServlet("/SearchLog")
public class SearchLog extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchLog() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		WalletManager obj = new WalletManager();
		obj.setDate(request.getParameter("date"));
		obj.setUid(String.valueOf(request.getSession().getAttribute("user")));
		obj.setTyp(request.getParameter("typ"));
		
		out.write("");
	}
}