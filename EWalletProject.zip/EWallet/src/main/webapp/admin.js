function createRequestObject() {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}
var http = createRequestObject();

function changeStat(id){
    up_id_mess.style.display = "block";
    http.open("get", "ChangeStat?uid=" + id);
    http.onreadystatechange = changeStatResponse;
    http.send(null);
}
function changeStatResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        document.location.reload(true);
    }
}

var img = document.getElementById("kycimg");
var kyc_mess = document.getElementById("kyc-mess");
function viewKyc(id){
    var image = new Image();
    var path = "Images/kyc/" + id + "_kyc.png";
    image.src = path;
    img.style.display = "block";
    if(image.width == 0){
        img.src = "Images/kyc/kyc.png";
    }
    else{
        img.src = path;
    }
    kyc_mess.style.display = "block";
    kyc_mess.style.color = "#009500";
    kyc_mess.innerHTML = "Please Scroll down for viewing KYC Document"
}

var up_id_mess = document.getElementById("up-id-mess");
function signUpId(){
    id = document.getElementById("up-id").value
    if (id.length > 4) {
        up_id_mess.style.display = "block";
        http.open("get", "CheckId?uid=" + id);
        http.onreadystatechange = signUpIdResponse;
        http.send(null);
    }
    else{
        up_id_mess.style.display = "none";
    }
}
function signUpIdResponse() {
    if(http.readyState == 4){
        response = http.responseText;
        up_id_mess.style.color = "#f00";
        if(response == "no"){
            up_id_mess.innerHTML = "Available";
            up_id_mess.style.color = "#009500";
        }
        else if(response == "yes"){
            up_id_mess.innerHTML = "Not available";
        }
        else{
            up_id_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var up_mess = document.getElementById("up-mess");
function newCompany(){
    event.preventDefault();
    up_mess.style.display = "block";
    up_mess.style.color = "#f00";
    id = document.getElementById("up-id").value;
    em = document.getElementById("up-em").value;
    if(id.length > 2 && em.length > 12){
        http.open("get", "SignUp?uid=" + id + "&typ=Company&em=" + em);
        http.onreadystatechange = newCompanyResponse;
        http.send(null);
    }
    else{
        up_mess.innerHTML = "Please provide correct data";
    }
}
function newCompanyResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "success"){
            up_mess.style.color = "#009500";
            up_mess.innerHTML = "Congratulations Compnay registered successfully";
        }
        else if(response == "failed"){
            up_mess.innerHTML = "Please check your userid or password";
        }
        else{
            up_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var new1 = document.getElementById("new-1");
var new1_mess = document.getElementById("new1-mess");
new1.addEventListener("input", () => {
    if(0 < new1.value.length){
        new1_mess.style.display = "block";

        if(4 > new1.value.length){
            new1_mess.innerHTML = "Weak";
            new1_mess.style.color = "#f00";
        }
        else if(4 <= new1.value.length && new1.value.length < 8){
            new1_mess.innerHTML = "Medium";
            new1_mess.style.color = "#cebd00";
        }
        else{
            new1_mess.innerHTML = "Strong";
            new1_mess.style.color = "#009500";
        }
    }
    else{
        new1_mess.style.display = "none";
    }
})
var new2 = document.getElementById("new-2");
var new2_mess = document.getElementById("new2-mess");
new2.addEventListener("input", () => {
    if(0 < new2.value.length){
        new2_mess.style.display = "block";

        if(new1.value != new2.value){
            new2_mess.innerHTML = "Password Doesn't Matched";
            new2_mess.style.color = "#f00";
        }
        else{
            new2_mess.innerHTML = "Password Matched";
            new2_mess.style.color = "#009500";
        }
    }
    else{
        new2_mess.style.display = "none";
    }
})

var pass_mess = document.getElementById("pass-mess");
function changePass(){
    old = document.getElementById("old").value;
    new1 = document.getElementById("new-1").value;
    new2 = document.getElementById("new-2").value;
    pass_mess.style.color = "#f00";
    pass_mess.style.display = "block";
    if(old.length > 0 && new1 == new2 && new1.length > 7){
        http.open("get", "ChangePass?psw=" + old + "&npsw=" + new1);
        http.onreadystatechange = changePassResponse;
        http.send(null);
    }
    else{
        pass_mess.innerHTML = "Please Enter Correct Data";
    }
}
function changePassResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            pass_mess.innerHTML = "Password Does Not Change";
        }
        else if(response == "success"){
            pass_mess.innerHTML = "Password Change Successfully";
            pass_mess.style.color = "#009500";
        }
        else if(response == "wrong pass"){
            pass_mess.innerHTML = "Your old Password is Wrong";
        }
    }
}

function block(value){
    var home = document.getElementById("home").style;
    var comp = document.getElementById("comp").style;
    var pass = document.getElementById("pass").style;

    var home_li = document.getElementById("home-li");
    var comp_li = document.getElementById("comp-li");

    if(value == 'home'){
        home.display = "block";
        comp.display = pass.display = "none";
        home_li.style = "background: #18173a; color: #fff;";
        comp_li.style = "background: transparent; color: #18173a;";

        img.style.display = "none";
        kyc_mess.style.display = "none";
    }
    else if(value == 'comp'){
        comp.display = "block";
        home.display = pass.display = "none";
        comp_li.style = "background: #18173a; color: #fff;";
        home_li.style = "background: transparent; color: #18173a;";
        
        document.getElementById("new-comp").reset();
        up_id_mess.style.display = "none";
        up_mess.style.display = "none";
    }
    else if(value == 'pass'){
        pass.display = "block";
        home.display = comp.display = "none";
        home_li.style = comp_li.style = "background: transparent; color: #18173a;";
        document.getElementById("pass-form").reset();
        pass_mess.style.display = "none";
    }
}