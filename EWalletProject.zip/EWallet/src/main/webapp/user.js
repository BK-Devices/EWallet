function createRequestObject() {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}
var http = createRequestObject();

var add_mess = document.getElementById("add-mess");
function addMoney(){
    event.preventDefault();
    add_mess.style.display = "block";
    add_mess.style.color = "#f00";
    bal = document.getElementById("add-amt").value;
    if (bal > 0){
        http.open("get", "MoneyOpr?typ=add&bal=" + bal);
        http.onreadystatechange = addMoneyResponse;
        http.send(null);
    }
    else {
        add_mess.innerHTML = "Please Enter Correct Data";
    }
}
function addMoneyResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            add_mess.innerHTML = "Money Not Added";
        }
        else if(response == "success"){
            add_mess.innerHTML = "Money Added Successfully";
            add_mess.style.color = "#009500";
        }
        else{
            add_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var trans_mess = document.getElementById("trans-mess");
function transferMoney(){
    event.preventDefault();
    trans_mess.style.display = "block";
    trans_mess.style.color = "#f00";
    bal = document.getElementById("trans-amt").value;
    id = document.getElementById("trans-id").value;
    if (bal > 0){
        http.open("get", "MoneyOpr?typ=friend&bal=" + bal + "&towid=" + id);
        http.onreadystatechange = transferMoneyResponse;
        http.send(null);
    }
    else {
        trans_mess.innerHTML = "Please Enter Correct Data";
    }
}
function transferMoneyResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            trans_mess.innerHTML = "Money Not Transfered";
        }
        else if(response == "success"){
            trans_mess.innerHTML = "Money Transfered Successfully";
            trans_mess.style.color = "#009500";
        }
        else if(response == "not found"){
            trans_mess.innerHTML = "Please Check Receiver Wallet Id";
        }
        else if(response == "low balance"){
            trans_mess.innerHTML = "You have Insufficient Balance";
        }
        else{
            trans_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var rech_mess = document.getElementById("rech-mess");
function recharge(){
    event.preventDefault();
    rech_mess.style.display = "block";
    rech_mess.style.color = "#f00";

    bal = document.getElementById("rech-amt").value;
    comp = document.getElementById("rech-comp").value;
    mono = document.getElementById("rech-mono").value;
    if (bal > 0 && mono.length == 10){
        http.open("get", "MoneyOpr?typ=rech&bal=" + bal + "&comp=" + comp + "&mono=91" + mono);
        http.onreadystatechange = rechargeResponse;
        http.send(null);
    }
    else {
        rech_mess.innerHTML = "Please Enter Correct Data";
    }
}
function rechargeResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            rech_mess.innerHTML = "Recharge Was unsuccessful";
        }
        else if(response == "success"){
            rech_mess.innerHTML = "Recharge Successfully";
            rech_mess.style.color = "#009500";
        }
        else if(response == "not found"){
            rech_mess.innerHTML = "Sorry Company Not Found";
        }
        else if(response == "low balance"){
            rech_mess.innerHTML = "You have Insufficient Balance";
        }
        else{
            rech_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var bill_mess = document.getElementById("bill-mess");
function bill(){
    event.preventDefault();
    bill_mess.style.display = "block";
    bill_mess.style.color = "#f00";

    bal = document.getElementById("bill-amt").value;
    comp = document.getElementById("bill-comp").value;
    if (bal > 0){
        http.open("get", "MoneyOpr?typ=bill&bal=" + bal + "&comp=" + comp);
        http.onreadystatechange = billResponse;
        http.send(null);
    }
    else {
        bill_mess.innerHTML = "Please Enter Correct Data";
    }
}
function billResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            bill_mess.innerHTML = "Bill Payment Was unsuccessful";
        }
        else if(response == "success"){
            bill_mess.innerHTML = "Bill Payment Successfully";
            bill_mess.style.color = "#009500";
        }
        else if(response == "not found"){
            bill_mess.innerHTML = "Sorry Company Not Found";
        }
        else if(response == "low balance"){
            bill_mess.innerHTML = "You have Insufficient Balance";
        }
        else{
            bill_mess.innerHTML = "Sorry Connection Error";
        }
    }
}

var log_mess = document.getElementById("log-mess");
function searchLog(val){
    event.preventDefault();
    document.getElementById("log-1").style.display = "none";
    document.getElementById("log-2").style.display = "block";
    log_mess.style.display = "block";
    log_mess.style.color = "#f00";
    var typ = "";

    if(val == "date"){
        typ = "date";
        date = document.getElementById("log-date").value;
    }
    else if(val == "month"){
        typ = "month";
        date = document.getElementById("log-month").value;
    }

    if(date != ""){
        http.open("get", "SearchLog?typ=" + typ + "&date=" + date);
        http.onreadystatechange = searchLogResponse;
        http.send(null);
    }
    else {
        log_mess.innerHTML = "Please Enter Correct Data";
    }
}
function searchLogResponse(){
    if(http.readyState == 4){
        response = http.responseText;
    }
}

var new1 = document.getElementById("new-1");
var new1_mess = document.getElementById("new1-mess");
new1.addEventListener("input", () => {
    if(0 < new1.value.length){
        new1_mess.style.display = "block";

        if(4 > new1.value.length){
            new1_mess.innerHTML = "Weak";
            new1_mess.style.color = "#f00";
        }
        else if(4 <= new1.value.length && new1.value.length < 8){
            new1_mess.innerHTML = "Medium";
            new1_mess.style.color = "#cebd00";
        }
        else{
            new1_mess.innerHTML = "Strong";
            new1_mess.style.color = "#009500";
        }
    }
    else{
        new1_mess.style.display = "none";
    }
})
var new2 = document.getElementById("new-2");
var new2_mess = document.getElementById("new2-mess");
new2.addEventListener("input", () => {
    if(0 < new2.value.length){
        new2_mess.style.display = "block";

        if(new1.value != new2.value){
            new2_mess.innerHTML = "Password Doesn't Matched";
            new2_mess.style.color = "#f00";
        }
        else{
            new2_mess.innerHTML = "Password Matched";
            new2_mess.style.color = "#009500";
        }
    }
    else{
        new2_mess.style.display = "none";
    }
})

var pass_mess = document.getElementById("pass-mess");
function changePass(){
    old = document.getElementById("old").value;
    new1 = document.getElementById("new-1").value;
    new2 = document.getElementById("new-2").value;
    pass_mess.style.color = "#f00";
    pass_mess.style.display = "block";
    if(old.length > 0 && new1 == new2 && new1.length > 7){
        http.open("get", "ChangePass?psw=" + old + "&npsw=" + new1);
        http.onreadystatechange = changePassResponse;
        http.send(null);
    }
    else{
        pass_mess.innerHTML = "Please Enter Correct Data";
    }
}
function changePassResponse(){
    if(http.readyState == 4){
        response = http.responseText;
        if(response == "failed"){
            pass_mess.innerHTML = "Password Does Not Change";
        }
        else if(response == "success"){
            pass_mess.innerHTML = "Password Change Successfully";
            pass_mess.style.color = "#009500";
        }
        else if(response == "wrong pass"){
            pass_mess.innerHTML = "Your old Password is Wrong";
        }
    }
}

function block(value){
    var home = document.getElementById("home").style;
    var money = document.getElementById("money").style;
    var log = document.getElementById("log").style;
    var pass = document.getElementById("pass").style;
    var kyc = document.getElementById("kyc").style;
    var home_li = document.getElementById("home-li").style;
    var money_li = document.getElementById("money-li").style;
    var log_li = document.getElementById("log-li").style;

    if(value == 'home'){
        home.display = "block";
        money.display = log.display = pass.display = kyc.display = "none";

        home_li.background = "#18173a";
        home_li.color = "#fff";
        money_li.background = log_li.background = "transparent";
        money_li.color = log_li.color = "#18173a";
    }
    else if(value == 'money'){
        home.display = log.display = pass.display = kyc.display = "none";
        money.display = "block";

        money_li.background = "#18173a";
        money_li.color = "#fff";
        home_li.background = log_li.background = "transparent";
        home_li.color = log_li.color = "#18173a";

        money('trans');
    }
    else if(value == 'log'){
        home.display = money.display = pass.display = kyc.display = "none";
        log.display = "block";
        document.getElementById("log-1").style.display = "block";
        document.getElementById("log-2").style.display = "none";
        
        log_li.background = "#18173a";
        log_li.color = "#fff";
        money_li.background = home_li.background = "transparent";
        money_li.color = home_li.color = "#18173a";
    }
    else if(value == 'pass'){
        home.display = money.display = log.display = kyc.display = "none";
        pass.display = "block";

        home_li.background = money_li.background = log_li.background = "transparent";
        home_li.color = money_li.color = log_li.color = "#18173a";

        document.getElementById("pass-form").reset();
        pass_mess.style.display = "none";
    }
    else if(value == 'kyc'){
        home.display = money.display = log.display = pass.display = "none";
        kyc.display = "block";

        home_li.background = money_li.background = log_li.background = "transparent";
        home_li.color = money_li.color = log_li.color = "#18173a";

        document.getElementById("kyc-form").reset();
    }
}

function money(value){
    var trans = document.getElementById("trans").style;
    var rech = document.getElementById("rech").style;
    var bill = document.getElementById("bill").style;
    var add = document.getElementById("add").style;
    var trans_li = document.getElementById("trans-li").style;
    var rech_li = document.getElementById("rech-li").style;
    var bill_li = document.getElementById("bill-li").style;
    var add_li = document.getElementById("add-li").style;

    if(value == 'trans'){
        trans.display = "block";
        rech.display = bill.display = add.display = "none";
        document.getElementById("trans-form").reset();
        trans_li.background = "#18173a";
        trans_li.color = "#fff";
        rech_li.background = bill_li.background = add_li.background = "transparent"
        rech_li.color = bill_li.color = add_li.color = "#18173a"
    }
    else if(value == 'rech'){
        trans.display = bill.display = add.display = "none";
        rech.display = "block";
        document.getElementById("reach-form").reset();
        rech_li.background = "#18173a";
        rech_li.color = "#fff";
        trans_li.background = bill_li.background = add_li.background = "transparent"
        trans_li.color = bill_li.color = add_li.color = "#18173a"
    }
    else if(value == 'bill'){
        trans.display = rech.display = add.display = "none";
        bill.display = "block";
        document.getElementById("bill-form").reset();
        bill_li.background = "#18173a";
        bill_li.color = "#fff";
        rech_li.background = trans_li.background = add_li.background = "transparent"
        rech_li.color = trans_li.color = add_li.color = "#18173a"
    }
    else if(value == 'add'){
        trans.display = rech.display = bill.display = "none";
        add.display = "block";
        document.getElementById("add-form").reset();
        add_li.background = "#18173a";
        add_li.color = "#fff";
        rech_li.background = bill_li.background = trans_li.background = "transparent"
        rech_li.color = bill_li.color = trans_li.color = "#18173a"
    }
}